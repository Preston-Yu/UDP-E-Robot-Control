NaturalPoint, Inc.

The NatNet SDK is a simple Client/Server networking SDK for sending and receiving
data from Motive across networks.  NatNet uses the UDP protocol in conjunction
with either multicasting or point-to-point unicasting for transmitting data.

Please refer to the NatNet API USer's Guide for more information.
https://wiki.optitrack.com/index.php?title=NatNet_SDK

A list of changes made in each version can be found at the following website:
https://www.optitrack.com/support/downloads/developer-tools.html

