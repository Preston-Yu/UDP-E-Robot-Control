/*********************************************************************
 * \page   resource.h
 * \file   resource.h
 * \brief  
 *********************************************************************/

 //{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleClient3D.rc
//
#define IDD_NATNETSAMPLE_DIALOG         102
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDC_NATNETSAMPLE                109
#define IDR_MAINFRAME                   128
#define IDD_NATNET                      129
#define IDC_CONNECT                     1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_COMBO1                      1008
#define IDC_COMBO_CONNTYPE              1008
#define IDC_EDIT5                       1010
#define IDC_EDIT6                       1011
#define IDC_EDIT7                       1012
#define IDC_EDIT8                       1013
#define ID_FILE_CONNECT                 32771
#define IDM_CONNECT                     32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
